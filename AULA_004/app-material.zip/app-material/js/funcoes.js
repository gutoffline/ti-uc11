$('.sidenav').sidenav();

$('.carousel-slider').carousel({
    fullWidth: true,
    indicators:true
});

$('.modal').modal();